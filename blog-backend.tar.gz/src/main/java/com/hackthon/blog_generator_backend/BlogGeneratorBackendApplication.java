package com.hackthon.blog_generator_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogGeneratorBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogGeneratorBackendApplication.class, args);
	}

}
